# Revision-3 addendum (auto-generated from this run)

## Active learning, headline configuration (uncertainty+random, budget 500), mean ± sd over seeds
- MAIN: unc+random, budget 500: F1 after first retraining round 0.944 ± 0.009 (no-AL 0.795), AUC 0.991, detection delay 2172 samples, n=5
- oracle noise 5%: F1 after first retraining round 0.931 ± 0.011 (no-AL 0.795), AUC 0.989, detection delay 2172 samples, n=5
- oracle noise 10%: F1 after first retraining round 0.922 ± 0.012 (no-AL 0.795), AUC 0.986, detection delay 2172 samples, n=5
- oracle noise 20%: F1 after first retraining round 0.893 ± 0.014 (no-AL 0.796), AUC 0.977, detection delay 2172 samples, n=5
- oracle noise 30%: F1 after first retraining round 0.832 ± 0.047 (no-AL 0.795), AUC 0.956, detection delay 2172 samples, n=5
- oracle delay 1000: F1 after first retraining round 0.944 ± 0.009 (no-AL 0.795), AUC 0.991, detection delay 2172 samples, n=5
- oracle delay 5000: F1 after first retraining round 0.942 ± 0.012 (no-AL 0.795), AUC 0.991, detection delay 2172 samples, n=5
- labels observed 10%: F1 after first retraining round 0.959 ± 0.009 (no-AL 0.796), AUC 0.994, detection delay 2960 samples, n=5
- labels observed 1%: F1 after first retraining round 0.949 ± 0.014 (no-AL 0.795), AUC 0.989, detection delay 7957 samples, n=5
- label-free PH trigger: F1 after first retraining round 0.937 ± 0.005 (no-AL 0.795), AUC 0.990, detection delay 343 samples, n=5

## Attack families / adaptive / gradual drift (post-drift F1 without AL -> with AL)
- attack: path: pre 0.984; no-AL 0.794; AL 0.946; detection delay 2662
- attack: subdomain: pre 0.984; no-AL nan; AL nan; detection delay nan
- attack: query: pre 0.984; no-AL 0.769; AL 0.958; detection delay 292
- attack: homoglyph: pre 0.984; no-AL nan; AL nan; detection delay nan
- attack: hyphen: pre 0.984; no-AL nan; AL nan; detection delay nan
- attack: combined: pre 0.984; no-AL 0.557; AL 0.959; detection delay 109
- attack: gradual path (ramp 5000): pre 0.984; no-AL 0.793; AL 0.953; detection delay 7357
- attack: adaptive best-of-6: pre 0.984; no-AL 0.520; AL 0.938; detection delay 86
- Families that barely reduce the no-AL F1 are NOT effective evasions against this model; say so instead of presenting them as drift.

## Natural dataset shift (in-distribution -> External-2)
- natural shift: MAIN (500): AUC 0.889 -> 0.970; F1 0.941 -> 0.968; detection delay 2296
- natural shift: budget 100: AUC 0.889 -> 0.919; F1 0.940 -> 0.949; detection delay 2229
- natural shift: budget 250: AUC 0.889 -> 0.937; F1 0.940 -> 0.953; detection delay 2229
- natural shift: budget 1000: AUC 0.889 -> 0.986; F1 0.940 -> 0.979; detection delay 2229
- natural shift: label-free PH trigger: AUC 0.889 -> 0.954; F1 0.939 -> 0.960; detection delay 254
- External-2 is 89% phishing: prefer AUC. This is a naturally shifted stream but still not a timestamped, evolving campaign.

## OOD robustness (AUC; Hybrid)
- canonical URLs, train D1 only -> Dataset-2: AUC 0.924, balanced accuracy 0.628
- canonical URLs, train D1 only -> External-2: AUC 0.829, balanced accuracy 0.581
- canonical, train D1 + Dataset-2 (LODO) -> External-2 -> External-2: AUC 0.914, balanced accuracy 0.625
- canonical, train D1 + External-2 (LODO) -> Dataset-2 -> Dataset-2: AUC 0.960, balanced accuracy 0.673
- raw URLs, train D1 only -> Dataset-2: AUC 0.765, balanced accuracy 0.497
- raw URLs, train D1 only -> External-2: AUC 0.602, balanced accuracy 0.502
- If canonicalisation raises OOD AUC, the earlier sub-0.5 AUCs were format artefacts (scheme / www / trailing slash); if not, say that the OOD gap is a genuine distribution shift.

## Stacking / value of components (paired bootstrap)
- GramBeddings hybrid (ML+DL+IF) vs Baseline: pretrained distilbert-base-uncased (fine-tuned, 575k URLs): dF1 -0.00401 [-0.00472, -0.00331], dAUC -0.00125 [-0.00142, -0.00111]
- stack: all models + IF vs Baseline: pretrained distilbert-base-uncased (fine-tuned, 575k URLs): dF1 +0.00163 [+0.00124, +0.00204], dAUC +0.00008 [+0.00004, +0.00014]
- stack: all models (no IF) vs Baseline: pretrained distilbert-base-uncased (fine-tuned, 575k URLs): dF1 +0.00167 [+0.00126, +0.00209], dAUC +0.00011 [+0.00007, +0.00016]
- Isolation-Forest value: (all + IF) minus (all, no IF) vs paired: dF1 -0.00004 [-0.00016, +0.00010], dAUC -0.00003 [-0.00005, -0.00002]
- Claim an Isolation-Forest or stacking benefit ONLY if the CI excludes 0 and the effect is practically relevant; otherwise describe the IF as a low-cost auxiliary signal.

## Still-open limitations
- No timestamped data -> no true temporal validation.
- All drifts are simulated or dataset shifts, not an observed phishing campaign; the oracle is simulated.
- DeepTCN width/depth/dropout still not swept.
- OOD-robustness retraining uses REPEAT_TRAIN_FRAC of the training data and few seeds.