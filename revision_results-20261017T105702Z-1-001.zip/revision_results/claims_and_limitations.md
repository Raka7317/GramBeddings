# Claims supported by the experiments, and limitations (auto-generated from this run)

## 1. Is the hybrid better than its strongest branch (DeepTCN)?  [R4-4, R1-3, R5]
- Paired bootstrap (1000 resamples) Hybrid − DeepTCN: ΔF1 = +0.00027 [+0.00006, +0.00049], ΔAcc = +0.00026 [+0.00006, +0.00047], ΔAUC = -0.00038 [-0.00049, -0.00028]; exact McNemar p = 0.0159.
- The AUC difference is **negative with a CI excluding 0**: DeepTCN alone ranks URLs better than the hybrid. Do NOT claim a ranking improvement from fusion.
- The F1 CI excludes 0 but the effect is tiny (see Δ above); describe it as 'marginal', not 'meaningful'.
- The value of the hybrid must therefore be argued from **other** properties (drift monitoring, anomaly view, modularity, latency trade-offs), not from accuracy.

- Block-wise tests (30 disjoint blocks), Hybrid vs DeepTCN, F1: Wilcoxon p = 0.0339 (Holm 0.0339), paired-t p = 0.0194; hybrid better in 14/30 blocks. These capture test-sampling variance only.
- Repeated independent runs (random splits, n=6): Hybrid−DL ΔF1 = +0.00269 ± 0.00215, hybrid better in 6/6 runs, t-test p = 0.0279.
- Repeated independent runs (domain splits, n=10): Hybrid−DL ΔF1 = +0.00436 ± 0.00473, hybrid better in 8/10 runs, t-test p = 0.0171.

## 2. Meta-learner 'weights'  [R4-5]
- RF impurity importance is NOT a decision weight and must not be compared with runtime share. Use permutation importance instead (drop in AUC on eval): ML (SGD) +0.0064, DL (DeepTCN) +0.2569, Anomaly (IsoForest) +0.0002.

## 3. Drift detection and active learning  [R4-1, R4-2, R4-3, R5]
- Score-perturbation stress test, perturbation **re-applied** after retraining (R4-3): F1 after first retraining round no-AL 0.289 vs AL 0.289 -> **no recovery**.
  The old protocol (perturbation silently removed after retraining) gave AL F1 = 0.984; that 'recovery' was an artefact of the evaluation, because the perturbation is applied AFTER the model and cannot be undone by retraining the model.
- Input-level drift (phishing URLs padded with benign path tokens): F1 after first retraining round no-AL 0.796 -> AL 0.884. This is the experiment that supports a recovery claim; make it the main drift experiment of the paper.
- The score-perturbation experiment is a controlled stress test of the drift DETECTORS only. The perturbation is applied to the output scores, so retraining the base branches cannot undo it; no recovery is expected and none is claimed. It is not evidence of robustness to real concept drift.
- Recommended main AL configuration (uncertainty + random top-up, budget 500): F1 0.796 -> 0.955; budget 1000: 0.974.
- B_labels_observed_10pct: AL F1 0.880
- B_labels_observed_1pct: AL F1 0.881
- B_label_free_trigger(PH): AL F1 0.875
- B_oracle_delay_1000: AL F1 0.884
- B_oracle_delay_5000: AL F1 0.883
- B_oracle_noise_5pct: AL F1 0.878
- B_oracle_noise_10pct: AL F1 0.874
- B_oracle_noise_20pct: AL F1 0.861
- Uncertainty sampling vs random query: 0.884 vs 0.953 (evasion makes errors confident, so uncertainty sampling misses them).
- Which labels are needed online (R4-1): ADWIN and DDM need the true label of each monitored sample (or a labelled subsample); Page-Hinkley on the confidence score and KS tests on features need no labels. The simulator therefore reports a label-free trigger and a 10 % / 1 % labelled-subsample trigger. In deployment labels arrive late and only for a fraction of traffic.
- The ADWIN used here is a simplified fixed-max-window (1000) variant with a Hoeffding-style cut, not the full bucket-based ADWIN of Bifet & Gavaldà; say so in the paper (or swap in `river.drift.ADWIN`).

## 4. External / out-of-distribution evaluation  [R5, R1-4]
- In-dist eval (reference) (n=123,302, phishing rate 0.481): AUC ML 0.993 / DL 0.998 / Anomaly 0.597 / Hybrid 0.998; balanced acc 0.984, MCC 0.968, F1 0.984 @ in-dist threshold (F1 0.982 after threshold re-calibration with 500 labels); KS(DL) 0.018 vs gate 0.065 -> fallback not used, gated AUC 0.998.
- Dataset-2 (Kaggle, victusadi) (n=160,064, phishing rate 0.995): AUC ML 0.809 / DL 0.483 / Anomaly 0.716 / Hybrid 0.672; balanced acc 0.483, MCC -0.013, F1 0.981 @ in-dist threshold (F1 0.997 after threshold re-calibration with 500 labels); KS(DL) 0.494 vs gate 0.065 -> fallback USED, gated AUC 0.776.  **WARNING: extreme class balance - precision / F1 reflect the base rate; judge by AUC, balanced accuracy and MCC only.**
- External-2 (raw_data.csv) (n=89,557, phishing rate 0.889): AUC ML 0.438 / DL 0.907 / Anomaly 0.739 / Hybrid 0.889; balanced acc 0.609, MCC 0.315, F1 0.942 @ in-dist threshold (F1 0.940 after threshold re-calibration with 500 labels); KS(DL) 0.490 vs gate 0.065 -> fallback USED, gated AUC 0.592.
- On the 1 class-balanced external dataset(s), mean hybrid AUC is 0.889 (in-distribution 0.998); weakest branch for ranking: **ML**, strongest: **DL**. Gated (label-free fallback) AUC 0.592.
- Restricted to external URLs from domains never seen in training, hybrid AUC is 0.870.
- External-2 (raw_data.csv): model AUC ranking -> pretrained distilbert-base-uncased (fine-tuned, 575k URLs) 0.936; char-BiGRU 0.928; DL branch (DeepTCN) 0.907; char-Transformer (3L, d=128) 0.889; Hybrid (GramBeddings) 0.889; char-TFIDF + MultinomialNB 0.841; lexical + HistGradientBoosting 0.607; ML branch (SGD) 0.438
- Threshold re-calibration changes the operating point, not the ranking (AUC unchanged); the fallback is exploratory, not a fix.

## 5. Data integrity  [R1-4]
- 2,952 eval URLs (2.39 %) also occur in train; results on the de-duplicated eval set are F1 0.9828 / AUC 0.9978 (full: 0.9835 / 0.9979).
- Fraction of eval URLs whose registered domain is unseen in train: 33.8 %; see domain_disjoint_eval.csv and the 'domain' repeated runs for performance when whole domains are held out.
- Protocol: TF-IDF, scalers, SGD, IsolationForest and DeepTCN are fitted on the training part only; the meta-learner is fitted on the validation part only; the decision threshold is chosen on 5-fold out-of-fold validation predictions; the evaluation part is touched once for reporting.

## 6. Limitations to state explicitly in the paper
- No real temporal validation: the datasets carry no collection timestamps, so the split is random (stratified) and temporal drift is only simulated.
- Drift is simulated (score perturbation = oracle adversary applied after the model; input-level = benign-token padding). Neither is a naturally evolving phishing campaign.
- Active-learning labels come from a simulated oracle (ground truth of the held-out stream). Delayed / noisy / partially observed labels were simulated, not measured with human annotators.
- External generalisation is evidenced on 2 external dataset(s); Dataset-2 is almost entirely phishing (so only its AUC / balanced accuracy / MCC are interpretable); the OOD ranking quality of the DeepTCN branch is poor on it.
- Baselines re-trained on the identical split: char-TFIDF + MultinomialNB, lexical + HistGradientBoosting, char-Transformer (3L, d=128), char-BiGRU, pretrained distilbert-base-uncased (fine-tuned, 575k URLs) (neural baselines trained on the full training split; pretrained transformer on the full training split, 1 epoch). No published 2024-25 URL-detection system was re-implemented from its original code; numbers copied from other papers use other splits and are not comparable.
- Hyper-parameters of the DeepTCN (width, depth, dropout), the IsolationForest and the fine-tuning schedule were not swept; the ML branch, the meta-RF, detectors, budget, oracle noise/delay and drift severity were. Sweeps for the ML branch use training/validation subsamples.
- Repeated-run statistics use a reduced training fraction and few repeats (see N_REPEATS_*); with <6 runs a Wilcoxon test cannot reach p<0.05, so tests over runs are paired t-tests / sign counts.
- Statistical tests quantify sampling and training-seed variability on these datasets, not variability across phishing ecosystems.
- Latency figures are hardware-specific (Colab GPU/CPU) and exclude network/DNS cost; the system is lexical (URL-only): no page content, WHOIS or DNS features.
- Code must be deposited in a DOI-assigning repository (e.g. Zenodo) before resubmission; this cannot be done from the notebook.

## 7. Wording to change in the manuscript  [R4-6]
- 'no overfitting' -> 'no deterioration of validation F1 was observed over the reported epochs' (training/validation curves do not prove absence of overfitting).
- 'interpretable attention' -> 'attention weights provide a visualisation of where the model attends; they are not a faithful explanation'.
- 'robust to drift' -> 'detects and (for input-level drift) partially recovers from the specific simulated drifts studied'.
- 'decision weight of branch X = Y %' -> permutation importance (drop in AUC / F1 when the branch is shuffled); impurity importance is not a decision weight.
- 'hybrid improves on DeepTCN' -> only if the paired CI excludes 0 and the effect is practically relevant (see Section 1).
- 'AL recovers accuracy after drift' -> restrict to the input-level drift experiment; for the score-perturbation stress test no recovery is expected or observed.